// 'http://jxapi.kkbbi.com'测试站
// 'https://api.zhaogongdi.com'线上
// http://jxm.kkbbi.com/
//http://m.zhaogongdi.com/
export const serverUrl = 'https://api.zhaogongdi.com';

export const domianUrl = 'http://m.zhaogongdi.com/'