import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _144a5388 = () => interopDefault(import('../pages/gongyingshang/index.vue' /* webpackChunkName: "pages/gongyingshang/index" */))
const _25674254 = () => interopDefault(import('../pages/home/index.vue' /* webpackChunkName: "pages/home/index" */))
const _cb464d2c = () => interopDefault(import('../pages/login/index.vue' /* webpackChunkName: "pages/login/index" */))
const _745c4aa6 = () => interopDefault(import('../pages/luck/index.vue' /* webpackChunkName: "pages/luck/index" */))
const _71e5fa18 = () => interopDefault(import('../pages/register/index.vue' /* webpackChunkName: "pages/register/index" */))
const _6f915fd0 = () => interopDefault(import('../pages/reset/index.vue' /* webpackChunkName: "pages/reset/index" */))
const _ac72fb80 = () => interopDefault(import('../pages/user/index.vue' /* webpackChunkName: "pages/user/index" */))
const _10807d23 = () => interopDefault(import('../pages/coin/recharge.vue' /* webpackChunkName: "pages/coin/recharge" */))
const _a6386644 = () => interopDefault(import('../pages/common/create.vue' /* webpackChunkName: "pages/common/create" */))
const _49a3b62b = () => interopDefault(import('../pages/common/update.vue' /* webpackChunkName: "pages/common/update" */))
const _9e24cb98 = () => interopDefault(import('../pages/gongyingshang/info.vue' /* webpackChunkName: "pages/gongyingshang/info" */))
const _d31f6a5e = () => interopDefault(import('../pages/gongyingshang/user.vue' /* webpackChunkName: "pages/gongyingshang/user" */))
const _4fe07be2 = () => interopDefault(import('../pages/luck/luck.js' /* webpackChunkName: "pages/luck/luck" */))
const _a902a260 = () => interopDefault(import('../pages/set/change-phone.vue' /* webpackChunkName: "pages/set/change-phone" */))
const _2032e2b3 = () => interopDefault(import('../pages/set/report.vue' /* webpackChunkName: "pages/set/report" */))
const _15aef820 = () => interopDefault(import('../pages/user/collection.vue' /* webpackChunkName: "pages/user/collection" */))
const _22c22aeb = () => interopDefault(import('../pages/user/company.vue' /* webpackChunkName: "pages/user/company" */))
const _437f890e = () => interopDefault(import('../pages/user/contact.vue' /* webpackChunkName: "pages/user/contact" */))
const _29494972 = () => interopDefault(import('../pages/user/face-book.vue' /* webpackChunkName: "pages/user/face-book" */))
const _3ed00444 = () => interopDefault(import('../pages/user/get.vue' /* webpackChunkName: "pages/user/get" */))
const _329a5db0 = () => interopDefault(import('../pages/user/info.vue' /* webpackChunkName: "pages/user/info" */))
const _2865cb9b = () => interopDefault(import('../pages/user/invitation.vue' /* webpackChunkName: "pages/user/invitation" */))
const _4fa6b65a = () => interopDefault(import('../pages/user/isget.vue' /* webpackChunkName: "pages/user/isget" */))
const _780783f6 = () => interopDefault(import('../pages/user/personalSettings.vue' /* webpackChunkName: "pages/user/personalSettings" */))
const _270084cc = () => interopDefault(import('../pages/user/protocol.vue' /* webpackChunkName: "pages/user/protocol" */))
const _52981c38 = () => interopDefault(import('../pages/user/release/index.vue' /* webpackChunkName: "pages/user/release/index" */))
const _c729d90c = () => interopDefault(import('../pages/user/welfare.vue' /* webpackChunkName: "pages/user/welfare" */))
const _64387c9d = () => interopDefault(import('../pages/user/modfiy_company/modfiy_company.vue' /* webpackChunkName: "pages/user/modfiy_company/modfiy_company" */))
const _382fb5ab = () => interopDefault(import('../pages/user/modfiy_password/modfiy_password.vue' /* webpackChunkName: "pages/user/modfiy_password/modfiy_password" */))
const _e4b93c3e = () => interopDefault(import('../pages/user/set_top_page/set_top.vue' /* webpackChunkName: "pages/user/set_top_page/set_top" */))
const _38bea910 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))
const _6efcbbfb = () => interopDefault(import('../pages/_id/index.vue' /* webpackChunkName: "pages/_id/index" */))
const _60d16166 = () => interopDefault(import('../pages/_id/_id/index.vue' /* webpackChunkName: "pages/_id/_id/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/gongyingshang",
    component: _144a5388,
    name: "gongyingshang"
  }, {
    path: "/home",
    component: _25674254,
    name: "home"
  }, {
    path: "/login",
    component: _cb464d2c,
    name: "login"
  }, {
    path: "/luck",
    component: _745c4aa6,
    name: "luck"
  }, {
    path: "/register",
    component: _71e5fa18,
    name: "register"
  }, {
    path: "/reset",
    component: _6f915fd0,
    name: "reset"
  }, {
    path: "/user",
    component: _ac72fb80,
    name: "user"
  }, {
    path: "/coin/recharge",
    component: _10807d23,
    name: "coin-recharge"
  }, {
    path: "/common/create",
    component: _a6386644,
    name: "common-create"
  }, {
    path: "/common/update",
    component: _49a3b62b,
    name: "common-update"
  }, {
    path: "/gongyingshang/info",
    component: _9e24cb98,
    name: "gongyingshang-info"
  }, {
    path: "/gongyingshang/user",
    component: _d31f6a5e,
    name: "gongyingshang-user"
  }, {
    path: "/luck/luck",
    component: _4fe07be2,
    name: "luck-luck"
  }, {
    path: "/set/change-phone",
    component: _a902a260,
    name: "set-change-phone"
  }, {
    path: "/set/report",
    component: _2032e2b3,
    name: "set-report"
  }, {
    path: "/user/collection",
    component: _15aef820,
    name: "user-collection"
  }, {
    path: "/user/company",
    component: _22c22aeb,
    name: "user-company"
  }, {
    path: "/user/contact",
    component: _437f890e,
    name: "user-contact"
  }, {
    path: "/user/face-book",
    component: _29494972,
    name: "user-face-book"
  }, {
    path: "/user/get",
    component: _3ed00444,
    name: "user-get"
  }, {
    path: "/user/info",
    component: _329a5db0,
    name: "user-info"
  }, {
    path: "/user/invitation",
    component: _2865cb9b,
    name: "user-invitation"
  }, {
    path: "/user/isget",
    component: _4fa6b65a,
    name: "user-isget"
  }, {
    path: "/user/personalSettings",
    component: _780783f6,
    name: "user-personalSettings"
  }, {
    path: "/user/protocol",
    component: _270084cc,
    name: "user-protocol"
  }, {
    path: "/user/release",
    component: _52981c38,
    name: "user-release"
  }, {
    path: "/user/welfare",
    component: _c729d90c,
    name: "user-welfare"
  }, {
    path: "/user/modfiy_company/modfiy_company",
    component: _64387c9d,
    name: "user-modfiy_company-modfiy_company"
  }, {
    path: "/user/modfiy_password/modfiy_password",
    component: _382fb5ab,
    name: "user-modfiy_password-modfiy_password"
  }, {
    path: "/user/set_top_page/set_top",
    component: _e4b93c3e,
    name: "user-set_top_page-set_top"
  }, {
    path: "/",
    component: _38bea910,
    name: "index"
  }, {
    path: "/:id",
    component: _6efcbbfb,
    name: "id"
  }, {
    path: "/:id/:id",
    component: _60d16166,
    name: "id-id"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
