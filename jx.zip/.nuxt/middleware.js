const middleware = {}

middleware['userAgent'] = require('../middleware/userAgent.js')
middleware['userAgent'] = middleware['userAgent'].default || middleware['userAgent']

export default middleware
